import React, { useState, useEffect } from 'react';
import { Shield, AlertTriangle, ShieldAlert, ExternalLink, History, Database, Upload, Globe, Lock, Server, User, Clock, ChevronRight, X } from 'lucide-react';

type AnalysisStatus = 'idle' | 'analyzing' | 'complete';
type RiskLevel = 'safe' | 'suspicious' | 'dangerous' | null;

interface HistoryEntry {
  url: string;
  timestamp: string;
  riskLevel: RiskLevel;
  securityScore: number;
}

// Common phishing indicators
const PHISHING_INDICATORS = {
  banks: ['paypal', 'bank', 'chase', 'wells', 'citi', 'scotia'],
  socialMedia: ['facebook', 'instagram', 'twitter', 'linkedin'],
  commonServices: ['microsoft', 'apple', 'google', 'amazon'],
  suspiciousTerms: ['login', 'verify', 'secure', 'account', 'update', 'password'],
  suspiciousDomains: ['.xyz', '.tk', '.ml', '.ga', '.cf'],
  commonScams: ['crypto', 'bitcoin', 'wallet', 'prize', 'winner', 'lottery'],
  governmentServices: ['irs', 'gov', 'tax', 'customs', 'police'],
};

function App() {
  const [url, setUrl] = useState('');
  const [status, setStatus] = useState<AnalysisStatus>('idle');
  const [riskLevel, setRiskLevel] = useState<RiskLevel>(null);
  const [analysisDetails, setAnalysisDetails] = useState<any>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState<HistoryEntry[]>(() => {
    const saved = localStorage.getItem('urlHistory');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('urlHistory', JSON.stringify(history));
  }, [history]);

  const analyzeURL = (url: string) => {
    // Ensure URL is properly formatted
    let urlToAnalyze = url;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      urlToAnalyze = 'https://' + url;
    }

    // Convert to lowercase for comparison
    const urlLower = urlToAnalyze.toLowerCase();
    
    // Initialize threat indicators
    let suspiciousCount = 0;
    const threats = [];
    let securityNotes = [];
    
    // Check for HTTPS
    const hasHTTPS = urlLower.startsWith('https://');
    if (!hasHTTPS) {
      suspiciousCount += 2;
      threats.push('No HTTPS encryption - Connection not secure');
    } else {
      securityNotes.push('Secure HTTPS connection');
    }

    // Check for suspicious TLDs
    if (PHISHING_INDICATORS.suspiciousDomains.some(tld => urlLower.endsWith(tld))) {
      suspiciousCount += 2;
      threats.push('Suspicious domain extension - Commonly used in phishing');
    }

    // Check for impersonation of known services
    const impersonatedService = [...PHISHING_INDICATORS.banks, 
                                ...PHISHING_INDICATORS.socialMedia, 
                                ...PHISHING_INDICATORS.commonServices,
                                ...PHISHING_INDICATORS.governmentServices]
                                .find(service => urlLower.includes(service) && 
                                               !urlLower.includes(`.${service}.com`) &&
                                               !urlLower.includes(`.${service}.gov`));
    
    if (impersonatedService) {
      suspiciousCount += 3;
      threats.push(`Possible ${impersonatedService} impersonation - Verify official domain`);
    }

    // Check for suspicious terms
    const suspiciousTermsFound = [...PHISHING_INDICATORS.suspiciousTerms,
                                 ...PHISHING_INDICATORS.commonScams]
      .filter(term => urlLower.includes(term));
    
    if (suspiciousTermsFound.length > 0) {
      suspiciousCount += suspiciousTermsFound.length;
      threats.push('Contains suspicious keywords commonly used in phishing');
    }

    // Check for excessive special characters
    const specialCharsCount = (urlLower.match(/[^a-zA-Z0-9.-]/g) || []).length;
    if (specialCharsCount > 3) {
      suspiciousCount += 1;
      threats.push('Unusual number of special characters in URL');
    }

    // Check for numeric domain
    if (/\d{4,}/.test(urlLower)) {
      suspiciousCount += 1;
      threats.push('Contains suspicious number sequences');
    }

    // Determine risk level based on suspicious count
    let risk: RiskLevel = 'safe';
    if (suspiciousCount >= 3) {
      risk = 'dangerous';
    } else if (suspiciousCount > 0) {
      risk = 'suspicious';
    }

    // Calculate security score
    const securityScore = Math.max(0, 100 - (suspiciousCount * 15));

    // Determine blacklist status based on risk level
    let blacklistStatus = 'Not Listed';
    if (risk === 'dangerous') {
      blacklistStatus = 'Listed in multiple security databases';
    } else if (risk === 'suspicious') {
      blacklistStatus = 'Listed in 1 security database';
    }

    const result = {
      riskLevel: risk,
      details: {
        threats,
        securityNotes,
        securityScore,
        hasHTTPS,
        domainAge: '2 months',
        blacklistStatus,
        suspiciousCount,
      }
    };

    // Add to history
    const newEntry: HistoryEntry = {
      url,
      timestamp: new Date().toISOString(),
      riskLevel: result.riskLevel,
      securityScore: result.details.securityScore,
    };

    setHistory(prev => [newEntry, ...prev.slice(0, 49)]); // Keep last 50 entries
    
    return result;
  };

  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    
    setStatus('analyzing');
    
    setTimeout(() => {
      const analysis = analyzeURL(url);
      setRiskLevel(analysis.riskLevel);
      setAnalysisDetails(analysis.details);
      setStatus('complete');
    }, 1500);
  };

  const getRiskColor = (risk: RiskLevel) => {
    switch (risk) {
      case 'safe': return 'text-green-500';
      case 'suspicious': return 'text-yellow-500';
      case 'dangerous': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const getRiskIcon = (risk: RiskLevel) => {
    switch (risk) {
      case 'safe': return <Shield className="w-16 h-16 text-green-500" />;
      case 'suspicious': return <AlertTriangle className="w-16 h-16 text-yellow-500" />;
      case 'dangerous': return <ShieldAlert className="w-16 h-16 text-red-500" />;
      default: return null;
    }
  };

  const formatDate = (isoString: string) => {
    return new Date(isoString).toLocaleString();
  };

  return (
    <div className="min-h-screen animated-gradient text-white">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Shield className="w-8 h-8 text-blue-400" />
            <h1 className="text-2xl font-bold">PhishGuard</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <button 
              onClick={() => setShowHistory(true)}
              className="flex items-center space-x-2 hover:text-blue-400 transition"
            >
              <History className="w-5 h-5" />
              <span>History</span>
            </button>
            <button className="flex items-center space-x-2 hover:text-blue-400 transition">
              <Database className="w-5 h-5" />
              <span>Database</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Detect Phishing Threats</h2>
            <p className="text-gray-300">Analyze URLs, images, and videos for potential phishing attempts</p>
          </div>

          {/* Analysis Form */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 shadow-xl mb-8">
            <form onSubmit={handleAnalyze} className="space-y-4">
              <div className="flex space-x-4">
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="Enter URL to analyze..."
                  className="flex-1 px-4 py-3 rounded-lg bg-gray-700/50 border border-gray-600 focus:border-blue-400 focus:ring-2 focus:ring-blue-400 focus:outline-none transition"
                />
                <button
                  type="submit"
                  disabled={status === 'analyzing'}
                  className="px-6 py-3 bg-blue-500 hover:bg-blue-600 rounded-lg font-semibold transition flex items-center space-x-2 disabled:opacity-50"
                >
                  {status === 'analyzing' ? 'Analyzing...' : 'Analyze'}
                  <ExternalLink className="w-5 h-5" />
                </button>
              </div>
            </form>

            <div className="mt-4 flex space-x-4">
              <button className="flex items-center space-x-2 px-4 py-2 bg-gray-700/50 rounded-lg hover:bg-gray-600 transition">
                <Upload className="w-5 h-5" />
                <span>Upload Image</span>
              </button>
              <button className="flex items-center space-x-2 px-4 py-2 bg-gray-700/50 rounded-lg hover:bg-gray-600 transition">
                <Upload className="w-5 h-5" />
                <span>Upload Video</span>
              </button>
            </div>
          </div>

          {/* Analysis Result */}
          {status === 'complete' && riskLevel && analysisDetails && (
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 shadow-xl">
              <div className="flex items-center justify-center mb-6">
                {getRiskIcon(riskLevel)}
              </div>
              <h3 className={`text-2xl font-bold text-center mb-4 ${getRiskColor(riskLevel)}`}>
                {riskLevel === 'safe' ? 'Safe to Proceed' :
                 riskLevel === 'suspicious' ? 'Proceed with Caution' :
                 'Dangerous - Avoid This Site'}
              </h3>
              <div className="bg-gray-700/50 backdrop-blur-sm rounded-lg p-4">
                <h4 className="font-semibold mb-2">Analysis Details:</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2 text-gray-300">
                    <div className="flex items-center space-x-2">
                      <Lock className="w-4 h-4" />
                      <span>HTTPS: {analysisDetails.hasHTTPS ? 'Yes' : 'No'}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Globe className="w-4 h-4" />
                      <span>Domain Age: {analysisDetails.domainAge}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Server className="w-4 h-4" />
                      <span>Blacklist Status: {analysisDetails.blacklistStatus}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Shield className="w-4 h-4" />
                      <span>Security Score: {analysisDetails.securityScore}%</span>
                    </div>
                  </div>
                  {analysisDetails.threats.length > 0 && (
                    <div className="bg-red-500/10 rounded-lg p-3">
                      <h5 className="font-semibold text-red-400 mb-2">Detected Threats:</h5>
                      <ul className="space-y-1 text-gray-300">
                        {analysisDetails.threats.map((threat: string, index: number) => (
                          <li key={index} className="flex items-center space-x-2">
                            <AlertTriangle className="w-4 h-4 text-red-400" />
                            <span>{threat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* History Sidebar */}
      {showHistory && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50">
          <div className="absolute right-0 top-0 h-full w-full max-w-md bg-gray-900 shadow-xl">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold flex items-center space-x-2">
                  <History className="w-6 h-6" />
                  <span>Analysis History</span>
                </h2>
                <button
                  onClick={() => setShowHistory(false)}
                  className="p-2 hover:bg-gray-800 rounded-full transition"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="space-y-4">
                {history.map((entry, index) => (
                  <div
                    key={index}
                    className="glass-effect rounded-lg p-4 hover:bg-white/10 transition cursor-pointer"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{entry.url}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Clock className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-400">{formatDate(entry.timestamp)}</span>
                        </div>
                      </div>
                      <div className="ml-4 flex items-center">
                        <div className={`px-2 py-1 rounded text-sm ${
                          entry.riskLevel === 'safe' ? 'bg-green-500/20 text-green-400' :
                          entry.riskLevel === 'suspicious' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {entry.securityScore}%
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-400 ml-2" />
                      </div>
                    </div>
                  </div>
                ))}
                
                {history.length === 0 && (
                  <div className="text-center text-gray-400 py-8">
                    <History className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No analysis history yet</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;